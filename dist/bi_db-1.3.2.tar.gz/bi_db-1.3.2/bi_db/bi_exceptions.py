class RedshiftException(Exception):
    pass

class SnowflakeException(Exception):
    pass

class BackfillException(Exception):
    pass
